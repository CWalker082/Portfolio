// Charlie Walker
// 08/02/2024
// The purpose of this code is to define the methods of the InvestmentCalculator class to evaluate and output investment balances with/without monthly deposits.
#include <iostream>
#include <iomanip>
#include "InvestmentCalculator.h"

// Constructor to initialize attributes
InvestmentCalculator::InvestmentCalculator(double initial, double monthly, double interest, int years)
    : initial_investment(initial), monthly_deposit(monthly), annual_interest(interest), number_of_years(years) {}

// Calculate balance without monthly deposits
void InvestmentCalculator::CalculateWithoutDeposits() const {
    double balance = initial_investment;
    std::cout << "Year\tYear End Balance\tYear End Earned Interest" << std::endl;
    for (int year = 1; year <= number_of_years; ++year) {
        double interest = balance * (annual_interest / 100);
        balance += interest;
        std::cout << std::setw(4) << year
            << std::setw(20) << "$" << std::fixed << std::setprecision(2) << balance
            << std::setw(25) << "$" << std::fixed << std::setprecision(2) << interest << std::endl;
    }
}

// Calculate balance with monthly deposits
void InvestmentCalculator::CalculateWithDeposits() const {
    double balance = initial_investment;
    std::cout << "Year\tYear End Balance\tYear End Earned Interest" << std::endl;
    for (int year = 1; year <= number_of_years; ++year) {
        double total_interest = 0;
        for (int month = 1; month <= 12; ++month) {
            balance += monthly_deposit;
            double interest = balance * (annual_interest / 100 / 12);
            balance += interest;
            total_interest += interest;
        }
        std::cout << std::setw(4) << year
            << std::setw(20) << "$" << std::fixed << std::setprecision(2) << balance
            << std::setw(25) << "$" << std::fixed << std::setprecision(2) << total_interest << std::endl;
    }
}

// Display results for both scenarios
void InvestmentCalculator::DisplayResults() const {
    std::cout << "Balance and Interest Without Additional Monthly Deposits" << std::endl;
    CalculateWithoutDeposits();
    std::cout << std::endl << "Balance and Interest With Additional Monthly Deposits" << std::endl;
    CalculateWithDeposits();
}
