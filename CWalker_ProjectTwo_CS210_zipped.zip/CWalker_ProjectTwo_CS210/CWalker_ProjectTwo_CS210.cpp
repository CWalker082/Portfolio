// Charlie Walker
// 08/02/2024
// The purpose of tthis code is to handle user input, intialize the investment calculator, and display the results. 
#include <iostream>
#include "InvestmentCalculator.h"

// Function to run a test case
void runTest(double initial, double monthly, double interest, int years) {
    InvestmentCalculator calculator(initial, monthly, interest, years);
    calculator.DisplayResults();
    std::cout << "------------------------------------" << std::endl;
}

int main() {
    double initial, monthly, interest;
    int years;

    // Welcome message and input prompts
    std::cout << "Welcome to the Investment Calculator" << std::endl;
    std::cout << "Enter Initial Investment Amount: ";
    std::cin >> initial;
    std::cout << "Enter Monthly Deposit: ";
    std::cin >> monthly;
    std::cout << "Enter Annual Interest: ";
    std::cin >> interest;
    std::cout << "Enter Number of Years: ";
    std::cin >> years;

    // Create calculator object and display results
    InvestmentCalculator calculator(initial, monthly, interest, years);
    calculator.DisplayResults();

    return 0;
}
