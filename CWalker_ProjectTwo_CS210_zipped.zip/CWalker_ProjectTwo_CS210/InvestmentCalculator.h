// Charlie Walker
// 08/02/2024
// The purpose of this code is to declare the InvestmentCalculator class and its methods for calculating and displaying investment growth.
#ifndef INVESTMENT_CALCULATOR_H_
#define INVESTMENT_CALCULATOR_H_

class InvestmentCalculator {
private:
    double initial_investment;
    double monthly_deposit;
    double annual_interest;
    int number_of_years;

public:
    // Constructor
    InvestmentCalculator(double initial, double monthly, double interest, int years);

    // Methods to calculate and display results
    void CalculateWithoutDeposits() const;
    void CalculateWithDeposits() const;
    void DisplayResults() const;
};

#endif // INVESTMENT_CALCULATOR_H_
